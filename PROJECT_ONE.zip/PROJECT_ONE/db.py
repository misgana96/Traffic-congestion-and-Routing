import mysql.connector
cc = "connected";
print(cc)