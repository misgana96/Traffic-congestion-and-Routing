<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['middleware' => ['web']], function() {
    Route::get('/', 'HomeController@index');
    Route::get('/', 'HomeController@video');
    Route::get('/getCounts', 'HomeController@getCounts');

    Auth::routes();
	
	
	Route::get('/home', 'HomeController@index');
	Route::get('/home', 'HomeController@video');
	Route::post('/home', 'HomeController@camera_video_submit');
  //Route::get('/home', 'HomeController@camera_video');
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------
   Route::get('/cameras', 'CameraController@view_camera');
   Route::get('/add_camera', 'CameraController@Add_camera');
   Route::post('/add_camera', 'CameraController@camera_submit');

//------------------------------------------------------------------------
//--------------------------------------------------------------------------
//--------------------------------------------------------------------------


});
