<?php

namespace App\Http\Controllers;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\vehicle_data;
use App\cameras;
use App\accessed_camera;


//use Illuminate\Support\Facades\Auth;
//use App\Http\Requests;





class HomeController extends Controller
{
    

      /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }


    public function index(){
   
         return view('Home.home');

         }
    public function video(){
    	$vehicles_data = DB::table('vehicles_data')->where('vehicles_data.camera_IP', '=', '192.00.89.2')->get();
        $cameras = DB::select('select * from cameras');
        return view('Home.home',['cameras'=>$cameras, 'vehicles_data'=>$vehicles_data]);
         }
    public function camera_video_submit(Request $request){
            $this->validate($request,[
                'camera_IP' => 'required',
                'camera_location' => 'required',
            ]);
            $accessed_camera = new accessed_camera();
            $accessed_camera->camera_IP = $request->camera_IP;
            $accessed_camera->camera_location = $request->camera_location;
            $cameras = cameras::where('camera_location', '=', $request->camera_location)->get();
            foreach ($cameras as $Cameras) {
               $Cameras->camera_IP;
               $Cameras->camera_location;
            }
           if($request->camera_IP == $Cameras->camera_IP){
                $vehicles_data = DB::table('vehicles_data')->where('vehicles_data.camera_IP', '=', $request->camera_IP )->get();
                $cameras = DB::select('select * from cameras');

                return view('Home.home',['cameras'=>$cameras, 'vehicles_data'=>$vehicles_data]);
           }
            $accessed_camera->save();
            return redirect('/home'); 
            
            //return view('Home.home', ['vehicles_data'=>$vehicles_data, 'vehicles_data'=>$vehicles_data]);
        //$u = DB::table('cameras')
          //  ->leftjoi n('vehicles_data', 'vehicles_data.camera_location','=','cameras.camera_location')
            //->where('vehicles_data.camera_IP','=',$request->camera_IP)
            //->get();



      

    }

    public function getCounts()
    {
        $vehicles_data = DB::table('vehicles_data')->where('vehicles_data.camera_IP', '=', '192.00.89.2')->get();
        return '{ "count_up" : "'.$vehicles_data[count($vehicles_data) - 1]->Vehicle_count_up.'", "count_down" : "'.$vehicles_data[count($vehicles_data) - 1]->Vehicle_count_down.'", "count_total" : "'.$vehicles_data[count($vehicles_data) - 1]->Total_vehicle_count.'" }';
    }
}