<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class vehiclesController extends Controller
{
    //
}
