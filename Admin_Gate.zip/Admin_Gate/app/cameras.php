<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class cameras extends Model
{
    //
}
